# AI-Assisted Health Data Analytics Dashboard for Primary Health Centres

AICW fellowship learning project using a fictional dataset.

## Files
- `Project_Report.pdf` and `.docx`: report drafts
- `Project_Presentation.pptx`: presentation draft
- `PHC_Health_Data_Analysis.xlsx`: synthetic data and summary sheets
- `data/PHC_Visits_Synthetic.csv`: source dataset
- `docs/`: project notes

## Important
All 1,200 records are synthetic and must not be represented as real patient data. The workbook includes descriptive summaries and charts. A native Power BI `.pbix` dashboard is not included yet; it must be created in Power BI Desktop on a Windows computer. Do not claim it is complete until the file exists and has been checked.
