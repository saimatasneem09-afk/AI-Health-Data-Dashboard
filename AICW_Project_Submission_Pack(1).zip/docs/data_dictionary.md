Fields: Visit_ID, Visit_Date, Age_Group, Gender, Area, Service_Category, Medicines_Dispensed, Cost_INR, Status
All rows are fictional synthetic demonstration data.
