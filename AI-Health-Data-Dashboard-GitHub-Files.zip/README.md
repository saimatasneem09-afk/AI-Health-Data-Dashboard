# AI-Based Health Data Dashboard for Primary Health Centres

## Project overview
This student project demonstrates how routine Primary Health Centre (PHC) visit data can be organised, analysed and presented through a dashboard. Microsoft Excel is used for data cleaning and basic analysis, Power BI is used for interactive visualisation, and an AI assistant may be used to draft plain-language summaries that are checked against the data.

## Problem statement
Primary Health Centres collect health-service information every day. When information is stored in registers or separate spreadsheets, it can be difficult and time-consuming to organise and analyse. Manual reporting may also lead to calculation errors. This project proposes a simple workflow using Excel, Power BI and AI tools to organise sample data, explore trends and present useful summaries in an interactive dashboard.

## Objectives
- Understand the structure of a PHC visit dataset.
- Clean and organise records using Excel or Power Query.
- Summarise visits by month, area, age group and service category.
- Calculate simple indicators such as total visits and referral percentage.
- Build an interactive Power BI dashboard with charts, KPI cards and slicers.
- Use AI only to help explain results, and verify every statement against the data.

## Repository contents
- `data/PHC_Visits_Synthetic.csv` — 1,200 fictional sample visit records.
- `docs/project-overview.md` — project scope, workflow and responsible-use notes.
- `docs/data-dictionary.md` — explanation of dataset columns.
- `docs/PROJECT_SYNOPSIS.docx` — fellowship synopsis supplied for this project, if included.

## Tools
- Microsoft Excel / Power Query
- Microsoft Power BI Desktop
- Copilot or ChatGPT for draft summaries (optional)
- GitHub for project documentation and version control

## How to start
1. Download `data/PHC_Visits_Synthetic.csv`.
2. Open it in Excel and check column types, missing values and duplicate Visit_ID values.
3. Create PivotTables for visits by month, service category and area.
4. Import the cleaned data into Power BI.
5. Add KPI cards and charts, then add slicers for month, service and area.
6. If using AI to summarise findings, verify each claim against the data before including it.

## Dataset notice
**All records in this repository are synthetic and fictional.** They do not represent real patients, a real PHC, or actual medical outcomes. Do not use this sample dataset for clinical decisions.

## Current status
This repository contains starter documentation and a synthetic practice dataset. The Excel analysis and Power BI dashboard should be completed and added as the project progresses. Do not describe the dashboard as completed until it has actually been built and tested.
