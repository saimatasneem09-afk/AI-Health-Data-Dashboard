# Data Dictionary

| Column | Meaning | Example |
|---|---|---|
| Visit_ID | Fictional unique record ID | PHC0001 |
| Visit_Date | Date of the fictional visit | 2026-01-14 |
| Age_Group | Broad age band | 18-59 |
| Gender | Recorded category in sample data | Female |
| Area | Fictional area label | Area A |
| Service_Category | Type of service | General OPD |
| Medicines_Dispensed | Fictional quantity count | 2 |
| Cost_INR | Fictional amount in rupees | 50 |
| Status | Fictional visit status | Treated |

All rows are synthetic and for learning only. Values are not real health records.
