# Project Overview

## Project title
AI-Based Health Data Dashboard for Primary Health Centres

## Problem statement
Primary Health Centres collect health-service information every day. When information is stored in registers or separate spreadsheets, it can be difficult and time-consuming to organise and analyse. Manual reporting may also lead to calculation errors. This project proposes using Excel, Power BI and optional AI assistance to organise sample data, explore trends and present summaries.

## Proposed workflow
1. Review the synthetic dataset and understand each column.
2. Clean records in Excel or Power Query.
3. Analyse visits using formulas and PivotTables.
4. Build an interactive Power BI dashboard.
5. Draft plain-language summaries with an AI assistant, then verify them against the actual data.
6. Document the process and findings.

## Planned dashboard elements
- Total number of visits
- Average visits per day
- Visits by month
- Visits by service category
- Visits by area and age group
- Referral percentage
- Filters for month, service category and area

## Responsible use
The included data is fictional. No real patient names, phone numbers, addresses or personal identifiers are used. AI-generated explanations are not medical advice and must be checked against the dataset.
